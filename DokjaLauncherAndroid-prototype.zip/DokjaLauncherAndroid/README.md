# Dokja Launcher Android (prototype)

UI HTML/CSS/JS + Android Kotlin WebView shell + restricted native bridge.

**Honest status:** UI and native bridge are implemented. Minecraft Java runtime is not integrated yet.
The Play button calls native Android when packaged as an APK; native code validates the selected
configuration and explicitly reports that a runtime adapter is still missing. In a normal browser
preview it explains that the native bridge is unavailable.

See `RUNTIME_INTEGRATION.md` for build notes and the next integration seam.
