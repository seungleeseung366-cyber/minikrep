package com.dokja.launcher

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = false
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = false
        webView.settings.javaScriptCanOpenWindowsAutomatically = false
        webView.webChromeClient = WebChromeClient()

        // Only app-bundled local HTML is loaded. External navigation is blocked.
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.toString() != "file:///android_asset/index.html"
            }
        }

        webView.addJavascriptInterface(LauncherBridge(this), "AndroidLauncher")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }
}

class LauncherBridge(private val activity: Activity) {
    @JavascriptInterface
    fun getDeviceInfo(): String {
        val runtime = Runtime.getRuntime()
        return JSONObject()
            .put("android", android.os.Build.VERSION.RELEASE)
            .put("abi", android.os.Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown")
            .put("maxHeapMb", runtime.maxMemory() / (1024 * 1024))
            .toString()
    }

    @JavascriptInterface
    fun launchMinecraft(version: String, ramMb: Int, loader: String): String {
        val allowedVersions = setOf("1.21.1", "1.21.4", "1.20.1", "1.19.4", "1.18.2", "1.16.5")
        val allowedLoaders = setOf("Vanilla", "Fabric", "Forge")
        val maxHeapMb = Runtime.getRuntime().maxMemory() / (1024 * 1024)

        if (version !in allowedVersions) {
            return error("INVALID_VERSION", "Versi game tidak diizinkan.")
        }
        if (loader !in allowedLoaders) {
            return error("INVALID_LOADER", "Loader tidak dikenal.")
        }
        if (ramMb < 512 || ramMb > maxHeapMb) {
            return error("INVALID_RAM", "RAM diminta di luar batas heap aplikasi (${maxHeapMb} MB).")
        }

        // Deliberately no fake success: a real game runtime adapter must be wired here.
        return error(
            "RUNTIME_NOT_CONNECTED",
            "Bridge native aktif. Runtime Minecraft belum dipasang; belum ada game yang dijalankan."
        )
    }

    @JavascriptInterface
    fun showMessage(message: String) {
        val safeMessage = message.take(120)
        activity.runOnUiThread {
            Toast.makeText(activity, safeMessage, Toast.LENGTH_SHORT).show()
        }
    }

    private fun error(code: String, message: String): String {
        return JSONObject()
            .put("ok", false)
            .put("code", code)
            .put("message", message)
            .toString()
    }
}
