(() => {
  "use strict";

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => [...document.querySelectorAll(selector)];

  const state = {
    username: "GuestPlayer",
    version: "1.20.1",
    ram: 2048,
    loader: "Vanilla",
    mods: { Sodium: true, Lithium: true, FerriteCore: false },
    busy: false
  };

  let toastTimer;
  let playTimer;

  function showToast(message) {
    const toast = $("#toast");
    toast.textContent = message;
    toast.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
  }

  function setStatus(message, kind = "") {
    const status = $("#launch-status");
    status.innerHTML = `<span class="status-led ${kind}"></span><span></span>`;
    status.querySelector("span:last-child").textContent = message;
  }

  function syncConfig() {
    $("#ram-value").textContent = state.ram;
    $("#version-select").value = state.version;
    $("#ram-slider").value = state.ram;
    $("#launch-version").textContent = `Minecraft ${state.version}`;
    $("#launch-details").textContent = `${state.loader} · ${state.ram} MB allocated`;
    $("#settings-ram").textContent = `${state.ram} MB`;
    $("#library-version").textContent = state.version;
    $("#version-status").textContent = `Profile ready · demo only`;
    $$(".loader-option").forEach(button => {
      const selected = button.dataset.loader === state.loader;
      button.classList.toggle("selected", selected);
      button.setAttribute("aria-pressed", String(selected));
    });
    $$(".mod-row").forEach(row => {
      const name = row.querySelector(".mod-copy strong").textContent;
      row.querySelector(".mod-toggle").checked = !!state.mods[name];
    });

    const warning = $("#ram-warning");
    if (state.ram >= 6144) {
      warning.textContent = "RAM tinggi. Pastikan perangkat punya memori yang cukup.";
    } else if (state.ram <= 1536) {
      warning.textContent = "Alokasi rendah: cocok untuk profil ringan, tetapi bergantung pada mod dan versi.";
    } else {
      warning.textContent = "Atur RAM sesuai kapasitas perangkat kamu.";
    }
  }

  function navigate(target) {
    const section = document.getElementById(target);
    if (!section) return;
    $$(".page-section").forEach(page => page.classList.toggle("hidden", page !== section));
    $$(".nav-item").forEach(button => button.classList.toggle("active", button.dataset.target === target));
    $("#page-name").textContent = target.replace("-", " ").toUpperCase();
    if (target === "mods") section.scrollIntoView({ behavior: "smooth", block: "start" });
    else window.scrollTo({ top: 0, behavior: "smooth" });
  }

  $$(".nav-item").forEach(button => {
    button.addEventListener("click", () => navigate(button.dataset.target));
  });

  $("#version-select").addEventListener("change", event => {
    state.version = event.target.value;
    syncConfig();
    setStatus(`Profil versi ${state.version} dipilih. Belum ada file game yang dijalankan.`);
  });

  $("#ram-slider").addEventListener("input", event => {
    state.ram = Number(event.target.value);
    syncConfig();
  });

  $$(".loader-option").forEach(button => {
    button.addEventListener("click", () => {
      state.loader = button.dataset.loader;
      syncConfig();
      showToast(`Profil ${state.loader} dipilih (simulasi).`);
    });
  });

  $$(".mod-toggle").forEach(toggle => {
    toggle.addEventListener("change", () => {
      const row = toggle.closest(".mod-row");
      const name = row.querySelector(".mod-copy strong").textContent;
      state.mods[name] = toggle.checked;
      showToast(`${name}: ${toggle.checked ? "aktif" : "nonaktif"} di demo.`);
    });
  });

  $("#view-mods").addEventListener("click", () => {
    navigate("mods");
    showToast("Mod Manager demo — mod tidak dipasang ke game.");
  });

  $("#library-configure").addEventListener("click", () => navigate("dashboard"));

  function playDemo() {
    // On Android APK, this invokes the restricted native bridge. In browser preview,
    // no bridge exists and the UI reports that a native runtime is required.
    if (window.AndroidLauncher && typeof window.AndroidLauncher.launchMinecraft === "function") {
      try {
        showToast("Minecraft belum dijalankan: buka APK Android dengan runtime terintegrasi.");

  }

  $("#play-button").addEventListener("click", playDemo);
  $("#hero-play").addEventListener("click", playDemo);

  $("#profile-avatar").addEventListener("click", () => {
    $("#login-name").value = state.username === "GuestPlayer" ? "" : state.username;
    $("#login-modal").classList.remove("hidden");
    $("#login-name").focus();
  });
  $("#close-login").addEventListener("click", () => $("#login-modal").classList.add("hidden"));
  $("#login-modal").addEventListener("click", event => {
    if (event.target.id === "login-modal") $("#login-modal").classList.add("hidden");
  });

  $("#login-form").addEventListener("submit", event => {
    event.preventDefault();
    const name = $("#login-name").value.trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) {
      showToast("Nama harus 3–16 karakter: huruf, angka, underscore.");
      return;
    }
    state.username = name;
    $("#profile-avatar").textContent = name.slice(0, 1).toUpperCase();
    $("#username").value = name;
    $("#login-modal").classList.add("hidden");
    showToast(`Selamat datang, ${name}! (akun demo)`);
  });

  $("#save-profile").addEventListener("click", () => {
    const name = $("#username").value.trim();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) {
      showToast("Nama harus 3–16 karakter: huruf, angka, underscore.");
      return;
    }
    state.username = name;
    $("#profile-avatar").textContent = name.slice(0, 1).toUpperCase();
    showToast("Profil lokal berhasil diperbarui.");
  });

  const spinnerStyle = document.createElement("style");
  spinnerStyle.textContent = ".spinner{display:inline-block;width:12px;height:12px;border:2px solid #251a3c;border-top-color:transparent;border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}button:disabled{opacity:.7;cursor:wait}";
  document.head.appendChild(spinnerStyle);

  syncConfig();
})();
