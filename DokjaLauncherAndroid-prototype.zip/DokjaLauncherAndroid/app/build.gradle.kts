plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dokja.launcher"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dokja.launcher"
        minSdk = 24
        targetSdk = 28
        versionCode = 1
        versionName = "0.1.0"
    }
}
