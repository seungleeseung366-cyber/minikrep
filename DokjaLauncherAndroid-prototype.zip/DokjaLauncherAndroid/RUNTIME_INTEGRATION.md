# Dokja Launcher Android — Runtime integration notes

This project is an Android WebView shell with a small, validated JavaScript-to-native bridge.
It is **not yet a Minecraft launcher**: the bridge intentionally returns `RUNTIME_NOT_CONNECTED`
until a compatible Android Minecraft Java runtime is integrated.

## Project layout

- `app/src/main/assets/`: offline UI (HTML/CSS/JS)
- `MainActivity.kt`: local WebView host; external navigation is blocked
- `LauncherBridge`: validates version, loader, and requested memory before passing control onward
- `launchMinecraft(...)`: current integration seam for a real runtime adapter

## Build

Open this folder in Android Studio on a computer with Android SDK 35 and a compatible JDK,
then sync Gradle and build the `app` debug variant. Acode edits files but does not by itself
provide the full Android SDK/Gradle build environment. On-device build options depend on
which Android development toolchain is installed.

## Connecting a real runtime

Create a `GameRuntimeAdapter` implementation in native code with an explicit API such as:

`prepareAndLaunch(version, loader, ramMb, callback)`

The adapter must own version manifest resolution, authenticated account flow, asset/library
downloads, runtime selection, JVM arguments/classpath, native libraries, graphics integration,
and lifecycle/log reporting. Replace the `RUNTIME_NOT_CONNECTED` return in
`LauncherBridge.launchMinecraft()` only after that adapter is implemented and tested.

For Android Minecraft Java, this is a substantial native integration. Study an established
open-source launcher and its license before reusing code. Do not copy binaries or code without
following their license terms. Keep Microsoft authentication on a proper OAuth flow; never ask
users to enter Microsoft passwords into this WebView.

## Security notes

- The bridge is intentionally narrow; do not expose arbitrary shell commands or file paths.
- Keep only trusted, bundled UI in this WebView. Never load arbitrary websites while the bridge
  is attached.
- The current bridge validates input but does not launch processes, download game files, or
  claim that a game started.
